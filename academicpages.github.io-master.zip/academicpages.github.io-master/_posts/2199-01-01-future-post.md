---
title: 'Future Blog Post'
date: 2199-01-01
permalink: /posts/2012/08/blog-post-4/
tags:
  - cool posts
  - category1
  - category2
---

This post will show up by default. To disable scheduling of future posts, edit `config.yml` and set `future: false`. 
